export const levels = [
  {n:'Level 0',t:'Khởi động',sessions:'Buổi 1',desc:'Làm quen, bài nói đầu vào và ghi nhận điểm xuất phát.',icon:'🚀'},
  {n:'Level 1',t:'Body Language',sessions:'Buổi 2–7',desc:'Ánh mắt, tư thế, cử chỉ, biểu cảm và kết nối.',icon:'🧍'},
  {n:'Level 2',t:'Tone of Voice',sessions:'Buổi 8–12',desc:'Phát âm, âm lượng, tốc độ, khoảng ngừng và cảm xúc.',icon:'🎙️'},
  {n:'Level 3',t:'Content',sessions:'Buổi 13–17',desc:'Ý tưởng, cấu trúc, kể chuyện, mở bài và kết bài.',icon:'✍️'},
  {n:'Level 4',t:'Stage Skills',sessions:'Buổi 18–21',desc:'Làm chủ sân khấu, tương tác và xử lý tình huống.',icon:'🎭'},
  {n:'Level 5',t:'Final Speaker',sessions:'Buổi 22',desc:'Bài nói cuối khóa, đánh giá và chứng nhận.',icon:'🏆'}
];
export const skills = [
  ['Body Language',72],['Tone of Voice',64],['Content',58],['Stage Skills',69],['Confidence',76]
];
