import { Link, NavLink } from 'react-router-dom';
import { Menu, X, Crown } from 'lucide-react';
import { useState } from 'react';
export function PublicLayout({children}:{children:React.ReactNode}){
 const [open,setOpen]=useState(false);
 return <><header className="topbar"><Link to="/" className="brand"><span className="brand-mark"><Crown size={21}/></span><span><b>PUBLIC SPEAKING</b><small>DIỄN GIẢ NHÍ</small></span></Link><nav className={open?'nav open':'nav'}>{[['/','Trang chủ'],['/chuong-trinh','Chương trình'],['/gioi-thieu','Giới thiệu'],['/dang-ky','Đăng ký']].map(([to,l])=><NavLink key={to} to={to} onClick={()=>setOpen(false)}>{l}</NavLink>)}<Link to="/login" className="btn btn-dark">Đăng nhập</Link></nav><button className="menu" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></header><main>{children}</main><footer><div><b>Royal Public Speaking Club</b><p>Speak to Lead — Nói để dẫn dắt.</p></div><div><p>Chủ nhiệm: Đỗ Phúc Nhật Minh</p><p>© 2026 Public Speaking – Diễn Giả Nhí</p></div></footer></>
}
export function PortalLayout({children,role='Học viên'}:{children:React.ReactNode,role?:string}){
 return <div className="portal"><aside><Link to="/" className="brand light"><span className="brand-mark"><Crown size={20}/></span><span><b>RPS CLUB</b><small>Speak to Lead</small></span></Link><div className="role">{role}</div>{[['/student','Tổng quan'],['/journey','Lộ trình'],['/lessons','Bài học'],['/practice','Phòng luyện tập'],['/submit','Nộp bài'],['/achievements','Thành tích']].map(([to,l])=><NavLink key={to} to={to}>{l}</NavLink>)}<Link to="/" className="back">← Về trang chủ</Link></aside><section className="portal-main"><header className="portal-head"><div><small>PUBLIC SPEAKING – DIỄN GIẢ NHÍ</small><h3>Speak to Lead</h3></div><div className="avatar">MN</div></header>{children}</section></div>
}
