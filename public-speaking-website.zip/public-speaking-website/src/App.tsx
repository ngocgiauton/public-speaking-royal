import { Routes,Route } from 'react-router-dom';
import { PublicLayout,PortalLayout } from './components/Layout';
import Home from './pages/Home';import Program from './pages/Program';import About from './pages/About';import Register from './pages/Register';import Login from './pages/Login';import Student from './pages/Student';import Placeholder from './pages/Placeholder';
const Pub=({children}:{children:React.ReactNode})=><PublicLayout>{children}</PublicLayout>;
const Portal=({children}:{children:React.ReactNode})=><PortalLayout>{children}</PortalLayout>;
export default function App(){return <Routes><Route path="/" element={<Pub><Home/></Pub>}/><Route path="/chuong-trinh" element={<Pub><Program/></Pub>}/><Route path="/gioi-thieu" element={<Pub><About/></Pub>}/><Route path="/dang-ky" element={<Pub><Register/></Pub>}/><Route path="/login" element={<Login/>}/><Route path="/student" element={<Portal><Student/></Portal>}/>{[['/journey','My Journey'],['/lessons','Kho bài học'],['/practice','Phòng luyện tập'],['/submit','Nộp bài'],['/achievements','Thành tích']].map(([p,t])=><Route path={p} element={<Portal><Placeholder title={t}/></Portal>}/>)}</Routes>}
